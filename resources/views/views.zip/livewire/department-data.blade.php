<div>
    <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Voluptatibus autem vitae, molestias soluta perspiciatis, placeat veritatis illo doloribus quidem, laudantium delectus quo totam aliquam consequatur? Voluptates consectetur in repellendus nobis.</p>
    {{-- Nothing in the world is as soft and yielding as water. --}}
</div>

<a href="/">
    <img src="assets\Asset.ico" alt="Next Media">
</a>
